# geodata

Pour utiliser les données il suffit de télécharger le dépôt puis de le décompresser. Vous pourrez ensuite jouer l'ensemble des exemples proposés.    

## lot.gpkg

Ce fichier contient plusieurs couches d'information.

- **departements** : les départements français métropolitains, [Admin Express COG Carto 3.0, IGN - 2021](https://geoservices.ign.fr/adminexpress);
- **communes** : les communes du département du Lot (46) avec des données sur la population active occupée âgée de 25 à 54 ans, par secteur d'activité et sexe, au lieu de résidence, en 2017, [BD CARTO® 4.0, IGN - 2021](https://geoservices.ign.fr/bdcarto) & [Recensements harmonisés - Séries départementales et communales, INSEE - 2020](https://www.insee.fr/fr/statistiques/1893185);
- **routes** : les routes de la commune de Gramat et alentours (46128), [BD CARTO® 4.0, IGN - 2021](https://geoservices.ign.fr/bdcarto);
- **restaurants** : les restaurants du Lot, [Base permanente des équipements (BPE), INSEE - 2021](https://www.insee.fr/fr/statistiques/3568638?sommaire=3568656);
- **elevations** : une grille régulière de points d'altitude (pas d'1 km), [Jarvis A., H.I. Reuter, A. Nelson, E. Guevara, 2008, Hole-filled seamless SRTM data V4, International Centre for Tropical Agriculture (CIAT)](http://srtm.csi.cgiar.org).

## com.csv

Ce fichier tabulaire contient des informations complémentaire sur la population active occupée âgée de 25 à 54 ans, par secteur d'activité et sexe, au lieu de résidence, en 2017, [Recensements harmonisés - Séries départementales et communales, INSEE - 2020](https://www.insee.fr/fr/statistiques/1893185).

- le nombre d’actifs (ACT);
- le nombre d’actifs dans l’industrie (IND);
- la part des actifs dans la population totale (SACT);
- la part des actifs dans l’industrie dans le total des actifs (SACT_IND).

## dvf.gpkg
Ce fichier contient des données sur certaines transactions immobilières réalisées à Montreuil et à Vincennes.

- **com** : les limites communales de Vincennes (94) et de Montreuil (93), [BD CARTO® 4.0, IGN - 2021](https://geoservices.ign.fr/bdcarto);
* **dvf** : un extrait des appartements vendus entre 2016 et 2021 dans les communes de Vincennes et de Montreuil, [Demandes de valeurs
    foncières géolocalisées, Etalab, 2021](https://www.data.gouv.fr/fr/datasets/demandes-de-valeurs-foncieres-geolocalisees/).
    
    