# 1  Exploration des données ----

## Importez les couches com et dvf ----
library(sf)
com <- st_read("data/dvf.gpkg", layer = "com", quiet = TRUE)
dvf <- st_read("data/dvf.gpkg", layer = "dvf", quiet = TRUE)

## Affichez les 2 couches importées ----
mf_map(com)
mf_map(dvf, add = TRUE)
## Avec le pkg mapsf :
library(mapsf)
mf_map(com)
mf_map(dvf, add = T, pch = 21, col = "ivory4", bg ="ivory")

## Quel est le prix médian de l'ensemble des transactions ? ----
median(dvf$prix)
median(dvf[["prix"]])

# 2 Géocoder la mairie de Montreuil ----

## Retrouver les coordonnées ----
library(tidygeocoder)
mairie <- geocode(
  .tbl = data.frame(adresse = "1 Place Jean Jaurès, 93100 Montreuil, France"),
  address = adresse
)
mairie

## Transformer en objet `sf` POINT ----
mairie_pt <- st_as_sf(mairie, coords= c("long", "lat"), crs = "EPSG:4326")

## Changement de projection ----
mairie_pt <- st_transform(mairie_pt, st_crs(com))


# 3 Créer un buffer de 500 m autour de la mairie ----
mairie_buffer <- st_buffer(x = mairie_pt, dist = 500)

## Affichage ----
mf_map(com)
mf_map(mairie_buffer, add = TRUE, lwd = 2, border = "blue")
mf_map(mairie_pt, add = TRUE, col = "red", lwd = 2, pch = 3, cex = 2)
mf_map(dvf, add = TRUE, cex = .5)

# 4 Extraire les appartements à l'intérieur du buffer et calculer le prix médian ----
inter <- st_intersection(dvf, mairie_buffer)
median(inter$prix)

# 5 Exercice supplémentaire ----

## Créer une grille régulière sur l'emprise des communes ----
grid <- st_make_grid(x = com, 
                     cellsize = units::set_units(50000, "m2"), 
                     square = FALSE)
grid <- st_sf(id = 1:length(grid), grid)
grid <- st_intersection(grid, st_geometry(com))

mf_map(grid, border = "ivory")
mf_map(com, col = NA, add = TRUE)
mf_map(dvf, pch = 21, col = "#940000", cex = .5, add = TRUE)

## Jointure spatiale entre les transactions et les carreaux de grille ----
dvf_com <- st_join(x = dvf, y = grid)

## Agrégation des prix des transactions par carreaux de grille ----
grid_prix <- aggregate(x  = list(prix_median = dvf_com$prix), 
                       by = list(id = dvf_com$id), 
                       FUN = "median")
## Compter les transactions par carreaux ----
grid_n <- aggregate(x  = list(n = dvf_com$id), 
                       by = list(id = dvf_com$id), 
                       FUN = "length")

## Joindre le prix median et le nombre de transactions à la grille ----
grid <- merge(grid, grid_prix, by = "id", all.x = TRUE)
grid <- merge(grid, grid_n, by = "id", all.x = TRUE)

## Selectionner les carreaux contenant au moins 5 transactions ----
grid_5 <- grid[!is.na(grid$n) & grid$n >= 10, ]

## Étude de la variable ----
summary(grid_5$prix_median)
boxplot(grid_5$prix_median)
hist(grid_5$prix_median, 25)

## Cartographie
bks <- c(min(grid_5$prix_median), seq(3000,9000,1000), max(grid_5$prix_median))
mf_export(grid_5, "img/prix_carreaux.png", width = 800)
mf_map(grid, border = "ivory", lwd = .5, add = TRUE)
mf_map(grid_5, "prix_median", "choro", 
       breaks = bks, pal = "Teal", 
       lwd = .5, border = 'ivory',
       leg_title = "Prix médian (€/m²)",
       leg_val_rnd = 0, 
       leg_pos = "topleft", 
       add = TRUE)
mf_map(com, col = NA, add = TRUE)
mf_map(dvf, pch = ".", col = "#941000", add = TRUE)
mf_title("Ventes d'appartements à Montreuil et Vincennes de 2016 à 2021")
mf_arrow(pos = "topright")
mf_scale(500, unit = "m")
mf_credits(paste0("T. Giraud - 2023\n", 
                  "BD CARTO®, IGN, 2021 & ", 
                  "Demandes de valeurs foncières géolocalisées, Etalab, 2021"))
dev.off()

