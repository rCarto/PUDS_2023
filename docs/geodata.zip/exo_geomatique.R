# 1  Exploration des données ----

## Importez les couches com et dvf ----
library(sf)
com <- st_read(dsn = "data/dvf.gpkg", layer = "com")
dvf <- st_read(...)

## Affichez les 2 couches importées ----
plot(st_geometry(...))
plot(st_geometry(...), add = TRUE)

## Quel est le prix médian de l'ensemble des transactions ? ----
median(...)

# 2 Géocoder la mairie de Montreuil ----

## Retrouver les coordonnées ----
library(tidygeocoder)
mairie <- geocode(.tbl = ..., address = ...)

## Transformer en objet `sf` POINT ----
mairie_pt <- st_as_sf(mairie, coords= c(..., ...), crs = ...)

## Changement de projection ----
mairie_pt <- st_transform(mairie_pt, ...)


# 3 Créer un buffer de 500 m autour de la mairie ----
mairie_buffer <- st_buffer(x = mairie_pt, dist = ...)


# 4 Extraire les appartements à l'intérieur du buffer et calculer le prix médian ----
inter <- st_intersection(..., ...)
median(...)
