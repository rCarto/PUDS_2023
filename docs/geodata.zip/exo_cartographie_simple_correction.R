# 2. Importer la couche des communes du département du Lot à partir du ----
# fichier geopackage **lot46.gpkg**.
library(sf)
st_layers('data/lot.gpkg')
com <- st_read("data/lot.gpkg", layer = "communes")

# 3. Importer le fichier **com.csv**.   ----
com_df <- read.csv("data/com.csv")


# 4. Joindre le jeu de données et la couche des communes. ----
com <- merge(com, com_df, by = "INSEE_COM", all.x = TRUE)


# 5. Créer une carte de la population active.  ----
library(mapsf)
# afficher les communes
mf_map(com, col = "ivory4", border = "ivory" , lwd = .3)
# afficher des cercles proportionnels
mf_map(x = com, var = "ACT", type = "prop",
       inches = .2, lwd = .5, col = "#881094",
       leg_title = "Nombre d'actifs",
       leg_pos = c(622700, 6372800))
mf_title("Répartition des actifs dans le Lot")


# 6. Créer une carte de la part de la population active dans la population totale.  ----
# Création d'un histogramme
htitle <- "Part de la population active ocuppée dans la population totale (Lot, 2017)"
hxlab <- "en %"
hist(com$SACT, main = htitle,  xlab = hxlab, freq = FALSE)
summary(com$SACT)

# choix de la méthode msd (utilisant moyenne et écart-type)
bks <- mf_get_breaks(com$SACT, breaks = "msd",
                     central = FALSE)
# Utilisation d'une palette dissymétrique équilibrée autour de la moyenne
cols <- mf_get_pal(c(3,4), palette = c("Mint", "Burg"))

# Création d'un histogramme avec les bornes sélectionnées
opar <- par(mar = c(5.1,2.1,2.1,2.1))
hist(com$SACT, breaks = bks, col = cols, xlab = hxlab,
     freq = FALSE, axes = FALSE, ylab = "",
     main = htitle, border = "grey80", ylim = c(-0.01, 0.07))
stripchart(x = com$SACT, pch = 21, bg = "grey20",
           col = "white",at = -0.005,
           jitter = 0.0025, add =T,
           method = "jitter", cex = .7, xlab = "")
axis(side = 1, at = c(seq(10,50,10)))
par(opar)

# Création de la carte
mf_map(com, "SACT","choro",
       breaks = bks, pal = cols,
       border = "ivory4", lwd = .2,
       leg_title = "Part des actifs\ndans la population\n(en %)",
       leg_val_rnd = 0)
mf_title("Répartition des actifs dans le Lot")



