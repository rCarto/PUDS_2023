library(sf)
library(mapsf)
# import des communes du Lot
com <- st_read("data/lot.gpkg", layer = "communes", quiet = TRUE)
# import du jeu de données
com_df <- read.csv("data/com.csv")
# jointure
com <- merge(com, com_df, by = "INSEE_COM", all.x = TRUE)
# import des départments français
dep <- st_read("data/lot.gpkg", layer = "departements", quiet = TRUE)

# Création d'un thème personnalisé
th <- mf_theme("green", mar = c(0,0,1.5,0), pos = "left")

# Cartographie du nombre total de travailleurs de l'industrie
mf_export(com, "img/n_ind.png", theme = th, width = 800)
mf_map(x = com, border = "white", lwd = .2, add = T)
mf_map(x = dep, lwd = 1, col = NA, add = TRUE, lend = 0)
mf_map(x = com, var = "IND", type = "prop",
       leg_title = "Nombre d'actifs\ntravaillant dans\nl'industrie")
mf_title("Répartition des actifs travaillant dans l'industrie - 2017")
mf_scale(5)
mf_arrow(pos = "topright")
# notez l'utilisation ici de paste0() qui permet de concatener des chaines
# de caractères et de \n qui permet d'aller à la ligne
mf_credits(paste0("Admin Express COG Carto 3.0, IGN - 2021 & ",
                  "BD CARTO® 4.0, IGN - 2021 ; Recensements harmonisés - ",
                  "Séries départementales et communales, INSEE - 2020\n",
                  "Auteurs : T. Giraud, 2023"))
dev.off()



# Cartographie de la part des actifs travaillant dans l'industrie
## Quelle est la forme de la distribution que nous voulons cartographier ?
hist(com$SACT_IND)
boxplot(com$SACT_IND, horizontal = TRUE)
summary(com$SACT_IND)

#### > Seules 2 communes ont 100% de travailleurs dans l'industrie
#### Ces communes ont moins de 15 actifs
# Sélection des communes ayant plus de 15 actifs
com_sel <- com[com$ACT > 15, ]
## Quelle est la forme de cette (nouvelle) distribution
hist(com_sel$SACT_IND)
boxplot(com_sel$SACT_IND, horizontal = TRUE)
summary(com_sel$SACT_IND)

# Creation d'un vecteur contenant les limites de classes en
# utilisant la méthode des quantiles
bks <- mf_get_breaks(com_sel$SACT_IND, nbreaks = 5,
                     breaks = "quantile")
hist(com_sel$SACT_IND, bks)

# export de la carte
mf_export(com, "img/s_ind.png", theme = th, width = 800)
# Cartographie
mf_map(x = com,
       var = "SACT_IND",
       type = "choro",
       breaks = bks,         # Utilisation des bornes de classes créées précédement
       leg_val_rnd = 0,      # arrondir les valeurs dans la légende
       pal = "Red-Yellow",   # Utilisation d'une palette de couleur
       leg_title = "Part des actifs\ntravaillant dans\nl'industrie",
       add = TRUE,
       col_na = "grey",
       leg_no_data = "Communes de moins de 15 actifs") # texte du no data dans la légende
mf_title("Répartition des actifs travaillant dans l'industrie - 2017")
mf_scale(5)
mf_arrow(pos = "topright")
mf_credits(paste0("Admin Express COG Carto 3.0, IGN - 2021 & ",
                  "BD CARTO® 4.0, IGN - 2021 ; Recensements harmonisés - ",
                  "Séries départementales et communales, INSEE - 2020\n",
                  "Auteurs : T. Giraud, 2023"))
dev.off()

# Nous allons maintenant combiner le nombre total d'actifs et la parts des travailleurs de l'industrie.
mf_export(com, "img/c_ind.png", theme = th, width = 800)
mf_map(x = com, border = "white", lwd = .2, add = TRUE)
mf_map(x = dep, lwd = 1, col = NA, add = TRUE, lend = 0)
mf_map(com, c("ACT", "SACT_IND"), "prop_choro",
       breaks = bks,
       pal = "Red-Yellow",
       inches = .4,
       border = "white", lwd = .7,
       leg_val_rnd =  c(0,1),
       leg_pos = c(538000,6442000, 538000, 6424000),  # ici les légendes sont positionnées manuellement
       leg_title = c("Nombre d'actifs",
                     "Part des actifs\ndans l'industrie (en %)"),
       col_na = "grey",
       leg_no_data = "Communes de moins de 15 actifs")

# Ajout d'annotations
mf_annotation(x = com[com$NOM_COM=="Biars-sur-Cère",],
              txt = "Andros",
              col_arrow = th$fg, halo = T, cex = 1)
mf_annotation(x = com[com$NOM_COM=="Figeac",],
              txt = "Industrie\naéronautique",
              col_arrow = th$fg, pos = "bottomright", halo = T, cex = 1)
mf_annotation(x = com[com$NOM_COM=="Gramat",],
              txt = "La Quercynoise",
              col_arrow = th$fg, pos = "topleft", s = 1, halo = T,
              cex = 1)

mf_title("Répartition des actifs travaillant dans l'industrie - 2017")

# ajout d'un carton ->
mf_inset_on(fig = c(.8,0.98,0.1,0.3))
mf_map(dep, lwd = .1)
mf_map(com, border = NA, add = T, col = th$fg)
box(col = th$fg, lwd = .5)
mf_inset_off()
# <- fin du carton
mf_scale(5)
mf_arrow("topright")
mf_credits(paste0("Admin Express COG Carto 3.0, IGN - 2021 & ",
                  "BD CARTO® 4.0, IGN - 2021 ; Recensements harmonisés - ",
                  "Séries départementales et communales, INSEE - 2020\n",
                  "Auteurs : T. Giraud, 2023"))
dev.off()

